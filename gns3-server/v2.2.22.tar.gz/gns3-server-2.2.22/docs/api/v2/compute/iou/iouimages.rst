/v2/compute/iou/images
------------------------------------------------------------------------------------------------------------------------------------------

.. contents::

GET /v2/compute/iou/images
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Retrieve the list of IOU images

Response status codes
**********************
- **200**: List of IOU images

Sample session
***************


.. literalinclude:: ../../../examples/compute_get_iouimages.txt

