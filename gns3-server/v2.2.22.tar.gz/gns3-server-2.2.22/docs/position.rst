Positions
=========

A project object contains the scene_height and scene_width properties. This defines the
size of the drawing area in px.

The position of the nodes are relative with 0,0 as center of the area.
