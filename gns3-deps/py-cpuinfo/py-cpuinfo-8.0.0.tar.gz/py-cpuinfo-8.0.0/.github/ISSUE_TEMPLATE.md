
# In your bug report please include:
* CPU architecture
* Operating System
* Python version
* Version of py-cpuinfo
