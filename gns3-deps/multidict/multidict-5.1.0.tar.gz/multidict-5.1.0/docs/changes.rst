.. _multidict_changes:

.. include:: ../CHANGES.rst

.. include:: ../HISTORY.rst
